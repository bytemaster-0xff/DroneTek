// 
// 
// 

#include "def.h.h"

void Def.hClass::init()
{


}


Def.hClass Def.h;

