// def.h.h

#ifndef _DEF_h
#define _DEF_h

#define null 0

#endif

