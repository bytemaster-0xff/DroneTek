#ifndef APPDATA_H
#define APPDATA_H

uint8_t LocalAddress = 20;

#endif