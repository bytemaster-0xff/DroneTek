// Main.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "arduino.h"

// Pin 13 has an LED connected on most Arduino boards.
// give it a name:
int led = 13;

// Helper function for logging to debug output and the console
void CustomLogging(char* str)
{
	OutputDebugStringA(str); // for VS Output
	printf(str); // for commandline output
}

int _tmain(int argc, _TCHAR* argv[])
{
	return RunArduinoSketch();
}

void setup()
{
	// TODO: Add your code here

	CustomLogging("Hello Blinky!\n");
	// initialize the digital pin as an output.
	pinMode(led, OUTPUT);

}

void loop()
{
	// TODO: Add your code here

	CustomLogging("LED ON\n");
	digitalWrite(led, HIGH);   // turn the LED on (HIGH is the voltage level)
	delay(1000);               // wait for a second
	CustomLogging("LED OFF\n");
	digitalWrite(led, LOW);    // turn the LED off by making the voltage LOW
	delay(1000);               // wait for a second
}


